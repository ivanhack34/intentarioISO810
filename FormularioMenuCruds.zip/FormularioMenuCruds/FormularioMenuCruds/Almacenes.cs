﻿using FormularioMenuCruds.Config;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormularioMenuCruds
{
    public partial class Almacenes : Form
    {
        public Almacenes()
        {
            InitializeComponent();
        }
        public DataTable Index2()
        {
            Conexion.Conectar();
            DataTable dataTable = new DataTable();
            string sql = "SELECT * FROM  Almacenes";
            SqlCommand cmd = new SqlCommand(sql, Conexion.Conectar());
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);

            adapter.Fill(dataTable);

            return dataTable;

        }

        private void btnAgregarArticulos_Click(object sender, EventArgs e)
        {
            Conexion.Conectar();
            string SQL_Insert = "INSERT INTO Almacenes ( Descripcion,Estado) VALUES (@Descripcion,@Estado)";
            SqlCommand command2 = new SqlCommand(SQL_Insert, Conexion.Conectar());


            command2.Parameters.AddWithValue("@Descripcion",txtDescripcionAlmacen.Text);
       
            command2.Parameters.AddWithValue("@Estado",txtDescripcionAlmacen.Text);
  
            command2.ExecuteNonQuery();

            MessageBox.Show("Datos añadidos correctamente!");

            dtGRIDviewAlmacen.DataSource = Index2();
        }

        private void dtGRIDviewArticulos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Almacenes_Load(object sender, EventArgs e)
        {

        }

        private void btnEditarAlmacen_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void btnEliminarAlmacen_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void LabelDescripcionAlmacen_Click(object sender, EventArgs e)
        {

        }

        private void txtDescripcionAlmacen_TextChanged(object sender, EventArgs e)
        {

        }

        private void LabelEstadoAlmacen_Click(object sender, EventArgs e)
        {

        }

        private void LabelidAlmacen_Click(object sender, EventArgs e)
        {

        }

        private void txtIDAlmacen_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEstadoAlmacen_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

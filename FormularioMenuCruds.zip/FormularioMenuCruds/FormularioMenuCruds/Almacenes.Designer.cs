﻿namespace FormularioMenuCruds
{
    partial class Almacenes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button4 = new System.Windows.Forms.Button();
            this.btnEliminarAlmacen = new System.Windows.Forms.Button();
            this.btnEditarAlmacen = new System.Windows.Forms.Button();
            this.btnAgregarAlmacen = new System.Windows.Forms.Button();
            this.dtGRIDviewAlmacen = new System.Windows.Forms.DataGridView();
            this.txtEstadoAlmacen = new System.Windows.Forms.TextBox();
            this.LabelEstadoAlmacen = new System.Windows.Forms.Label();
            this.LabelDescripcionAlmacen = new System.Windows.Forms.Label();
            this.LabelidAlmacen = new System.Windows.Forms.Label();
            this.txtIDAlmacen = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtDescripcionAlmacen = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dtGRIDviewAlmacen)).BeginInit();
            this.SuspendLayout();
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(841, 199);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(147, 34);
            this.button4.TabIndex = 31;
            this.button4.Text = "button4";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // btnEliminarAlmacen
            // 
            this.btnEliminarAlmacen.Location = new System.Drawing.Point(841, 105);
            this.btnEliminarAlmacen.Name = "btnEliminarAlmacen";
            this.btnEliminarAlmacen.Size = new System.Drawing.Size(147, 34);
            this.btnEliminarAlmacen.TabIndex = 30;
            this.btnEliminarAlmacen.Text = "Eliminar";
            this.btnEliminarAlmacen.UseVisualStyleBackColor = true;
            this.btnEliminarAlmacen.Click += new System.EventHandler(this.btnEliminarAlmacen_Click);
            // 
            // btnEditarAlmacen
            // 
            this.btnEditarAlmacen.Location = new System.Drawing.Point(429, 199);
            this.btnEditarAlmacen.Name = "btnEditarAlmacen";
            this.btnEditarAlmacen.Size = new System.Drawing.Size(147, 34);
            this.btnEditarAlmacen.TabIndex = 29;
            this.btnEditarAlmacen.Text = "Editar";
            this.btnEditarAlmacen.UseVisualStyleBackColor = true;
            this.btnEditarAlmacen.Click += new System.EventHandler(this.btnEditarAlmacen_Click);
            // 
            // btnAgregarAlmacen
            // 
            this.btnAgregarAlmacen.Location = new System.Drawing.Point(429, 105);
            this.btnAgregarAlmacen.Name = "btnAgregarAlmacen";
            this.btnAgregarAlmacen.Size = new System.Drawing.Size(147, 34);
            this.btnAgregarAlmacen.TabIndex = 28;
            this.btnAgregarAlmacen.Text = "Agregar";
            this.btnAgregarAlmacen.UseVisualStyleBackColor = true;
            this.btnAgregarAlmacen.Click += new System.EventHandler(this.btnAgregarArticulos_Click);
            // 
            // dtGRIDviewAlmacen
            // 
            this.dtGRIDviewAlmacen.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtGRIDviewAlmacen.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtGRIDviewAlmacen.Location = new System.Drawing.Point(15, 311);
            this.dtGRIDviewAlmacen.Name = "dtGRIDviewAlmacen";
            this.dtGRIDviewAlmacen.Size = new System.Drawing.Size(1053, 292);
            this.dtGRIDviewAlmacen.TabIndex = 27;
            this.dtGRIDviewAlmacen.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtGRIDviewArticulos_CellContentClick);
            // 
            // txtEstadoAlmacen
            // 
            this.txtEstadoAlmacen.Location = new System.Drawing.Point(136, 242);
            this.txtEstadoAlmacen.Name = "txtEstadoAlmacen";
            this.txtEstadoAlmacen.Size = new System.Drawing.Size(183, 20);
            this.txtEstadoAlmacen.TabIndex = 26;
            this.txtEstadoAlmacen.TextChanged += new System.EventHandler(this.txtEstadoAlmacen_TextChanged);
            // 
            // LabelEstadoAlmacen
            // 
            this.LabelEstadoAlmacen.AutoSize = true;
            this.LabelEstadoAlmacen.Location = new System.Drawing.Point(13, 245);
            this.LabelEstadoAlmacen.Name = "LabelEstadoAlmacen";
            this.LabelEstadoAlmacen.Size = new System.Drawing.Size(40, 13);
            this.LabelEstadoAlmacen.TabIndex = 25;
            this.LabelEstadoAlmacen.Text = "Estado";
            this.LabelEstadoAlmacen.Click += new System.EventHandler(this.LabelEstadoAlmacen_Click);
            // 
            // LabelDescripcionAlmacen
            // 
            this.LabelDescripcionAlmacen.AutoSize = true;
            this.LabelDescripcionAlmacen.Location = new System.Drawing.Point(13, 190);
            this.LabelDescripcionAlmacen.Name = "LabelDescripcionAlmacen";
            this.LabelDescripcionAlmacen.Size = new System.Drawing.Size(63, 13);
            this.LabelDescripcionAlmacen.TabIndex = 22;
            this.LabelDescripcionAlmacen.Text = "Descripcion";
            this.LabelDescripcionAlmacen.Click += new System.EventHandler(this.LabelDescripcionAlmacen_Click);
            // 
            // LabelidAlmacen
            // 
            this.LabelidAlmacen.AutoSize = true;
            this.LabelidAlmacen.Location = new System.Drawing.Point(13, 135);
            this.LabelidAlmacen.Name = "LabelidAlmacen";
            this.LabelidAlmacen.Size = new System.Drawing.Size(62, 13);
            this.LabelidAlmacen.TabIndex = 21;
            this.LabelidAlmacen.Text = "ID Almacen";
            this.LabelidAlmacen.Click += new System.EventHandler(this.LabelidAlmacen_Click);
            // 
            // txtIDAlmacen
            // 
            this.txtIDAlmacen.Location = new System.Drawing.Point(136, 135);
            this.txtIDAlmacen.Name = "txtIDAlmacen";
            this.txtIDAlmacen.Size = new System.Drawing.Size(183, 20);
            this.txtIDAlmacen.TabIndex = 19;
            this.txtIDAlmacen.TextChanged += new System.EventHandler(this.txtIDAlmacen_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(494, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(184, 39);
            this.label1.TabIndex = 18;
            this.label1.Text = "ALMACEN";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtDescripcionAlmacen
            // 
            this.txtDescripcionAlmacen.Location = new System.Drawing.Point(136, 190);
            this.txtDescripcionAlmacen.Name = "txtDescripcionAlmacen";
            this.txtDescripcionAlmacen.Size = new System.Drawing.Size(183, 20);
            this.txtDescripcionAlmacen.TabIndex = 34;
            this.txtDescripcionAlmacen.TextChanged += new System.EventHandler(this.txtDescripcionAlmacen_TextChanged);
            // 
            // Almacenes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1080, 615);
            this.Controls.Add(this.txtDescripcionAlmacen);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.btnEliminarAlmacen);
            this.Controls.Add(this.btnEditarAlmacen);
            this.Controls.Add(this.btnAgregarAlmacen);
            this.Controls.Add(this.dtGRIDviewAlmacen);
            this.Controls.Add(this.txtEstadoAlmacen);
            this.Controls.Add(this.LabelEstadoAlmacen);
            this.Controls.Add(this.LabelDescripcionAlmacen);
            this.Controls.Add(this.LabelidAlmacen);
            this.Controls.Add(this.txtIDAlmacen);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Almacenes";
            this.Text = "Almacenes";
            this.Load += new System.EventHandler(this.Almacenes_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtGRIDviewAlmacen)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button btnEliminarAlmacen;
        private System.Windows.Forms.Button btnEditarAlmacen;
        private System.Windows.Forms.Button btnAgregarAlmacen;
        private System.Windows.Forms.DataGridView dtGRIDviewAlmacen;
        private System.Windows.Forms.TextBox txtEstadoAlmacen;
        private System.Windows.Forms.Label LabelEstadoAlmacen;
        private System.Windows.Forms.Label LabelDescripcionAlmacen;
        private System.Windows.Forms.Label LabelidAlmacen;
        private System.Windows.Forms.TextBox txtIDAlmacen;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtDescripcionAlmacen;
    }
}
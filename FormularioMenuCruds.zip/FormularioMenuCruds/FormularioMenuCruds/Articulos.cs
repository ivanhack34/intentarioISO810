﻿using FormularioMenuCruds.Config;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormularioMenuCruds
{
    public partial class Articulos : Form
    {
        public Articulos()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Articulos_Load(object sender, EventArgs e)
        {
            Conexion.Conectar();
            dtGRIDviewArticulos.DataSource = Index();


        }


        public DataTable Index()
        {
            Conexion.Conectar();
            DataTable dataTable = new DataTable();
            string sql = "SELECT * FROM  Articulos";
            SqlCommand cmd = new SqlCommand(sql,Conexion.Conectar());
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);

            adapter.Fill(dataTable);

            return dataTable;
        
        }





        /// Botones de agregar,editar, eliminar etc...
        private void btnAgregarArticulos_Click(object sender, EventArgs e)
        {
            Conexion.Conectar();
            string SQL_Insert = "INSERT INTO Articulos (Descripcion, Existencia, IdentificadorTipoInventario,CostoUnitario,Estado) VALUES (@Descripcion, @Existencia, @IdentificadorTipoInventario,@CostoUnitario,@Estado)";
            SqlCommand command1 = new SqlCommand(SQL_Insert,Conexion.Conectar());

           
            command1.Parameters.AddWithValue("@Descripcion", txtDescripcionArticulos.Text);
            command1.Parameters.AddWithValue("@Existencia",txtExistenciaArticulos.Text);
            command1.Parameters.AddWithValue("@Estado", txtEstadoArticulos.Text);
            command1.Parameters.AddWithValue("@IdentificadorTipoInventario", txtIDTipoInventarioArticulos.Text);
            command1.Parameters.AddWithValue("@CostoUnitario", txtCostoUnitarioArticulos.Text);

            command1.ExecuteNonQuery();

            MessageBox.Show("Datos añadidos correctamente!");

            dtGRIDviewArticulos.DataSource = Index();
        }

        private void LabelDescripcionArticulos_Click(object sender, EventArgs e)
        {

        }

        private void btnEditarArticulos_Click(object sender, EventArgs e)
        {
            Conexion.Conectar();
            string editar = "UPDATE Articulos SET Descripcion = @Descripcion, Existencia=@Existencia, IdentificadorTipoInventario=@IdentificadorTipoInventario, CostoUnitario=@CostoUnitario,Estado=@Estado WHERE Descripcion = @Descripcion";
            SqlCommand cmd22 = new SqlCommand(editar,Conexion.Conectar());

            cmd22.Parameters.AddWithValue("@Descripcion", txtDescripcionArticulos.Text);
           
            cmd22.Parameters.AddWithValue("@Existencia", txtExistenciaArticulos.Text);
            cmd22.Parameters.AddWithValue("@IdentificadorTipoInventario", txtIDTipoInventarioArticulos.Text);
            cmd22.Parameters.AddWithValue("@CostoUnitario", txtCostoUnitarioArticulos.Text);
            cmd22.Parameters.AddWithValue("@Estado", txtEstadoArticulos.Text);

            cmd22.ExecuteNonQuery();

            MessageBox.Show("Los datos fueron actualizados correctamente");
            dtGRIDviewArticulos.DataSource= Index();
        }

        private void dtGRIDviewArticulos_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                txtDescripcionArticulos.Text = dtGRIDviewArticulos.CurrentRow.Cells[0].Value.ToString();
                txtEstadoArticulos.Text = dtGRIDviewArticulos.CurrentRow.Cells[1].Value.ToString();
                txtExistenciaArticulos.Text = dtGRIDviewArticulos.CurrentRow.Cells[2].Value.ToString();
                txtIDTipoInventarioArticulos.Text = dtGRIDviewArticulos.CurrentRow.Cells[3].Value.ToString();
                txtCostoUnitarioArticulos.Text = dtGRIDviewArticulos.CurrentRow.Cells[4].Value.ToString();
            } catch { }
    }

        private void btnEliminarArticulos_Click(object sender, EventArgs e)
        {
            Conexion.Conectar();
            string eliminar = "DELETE FROM Articulos WHERE Descripcion = @Descripcion";
            SqlCommand cmd3 = new SqlCommand(eliminar, Conexion.Conectar());
            cmd3.Parameters.AddWithValue("@Descripcion", txtDescripcionArticulos.Text);

            cmd3.ExecuteNonQuery();

            MessageBox.Show("Los datos fueron eliminados correctamente");


            dtGRIDviewArticulos.DataSource = Index();
        }

        private void btnNuevoArticulos_Click(object sender, EventArgs e)
        {
            txtIDarticulos.Clear();
            txtExistenciaArticulos.Clear();
            txtIDTipoInventarioArticulos.Clear();
            txtCostoUnitarioArticulos.Clear();
            txtDescripcionArticulos.Clear();
            txtEstadoArticulos.Clear(); 
        }
    }
}
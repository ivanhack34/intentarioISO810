﻿namespace FormularioMenuCruds
{
    partial class Trasacciones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtDescripcionTrasacciones = new System.Windows.Forms.TextBox();
            this.txtEstadoTrasacciones = new System.Windows.Forms.TextBox();
            this.LabelEstadoTrasacciones = new System.Windows.Forms.Label();
            this.LabelDescripcionTrasacciones = new System.Windows.Forms.Label();
            this.LabelidTrasacciones = new System.Windows.Forms.Label();
            this.txtIDTrasacciones = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.btnEliminarTrasacciones = new System.Windows.Forms.Button();
            this.btnEditarTrasacciones = new System.Windows.Forms.Button();
            this.btnAgregarTrasacciones = new System.Windows.Forms.Button();
            this.labelTrasacciones = new System.Windows.Forms.Label();
            this.dtGRIDviewTrasacciones = new System.Windows.Forms.DataGridView();
            this.txtCuentaContableTrasacciones = new System.Windows.Forms.TextBox();
            this.labelCuentaContableTrasacciones = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dtGRIDviewTrasacciones)).BeginInit();
            this.SuspendLayout();
            // 
            // txtDescripcionTrasacciones
            // 
            this.txtDescripcionTrasacciones.Location = new System.Drawing.Point(143, 97);
            this.txtDescripcionTrasacciones.Name = "txtDescripcionTrasacciones";
            this.txtDescripcionTrasacciones.Size = new System.Drawing.Size(183, 20);
            this.txtDescripcionTrasacciones.TabIndex = 40;
            // 
            // txtEstadoTrasacciones
            // 
            this.txtEstadoTrasacciones.Location = new System.Drawing.Point(143, 149);
            this.txtEstadoTrasacciones.Name = "txtEstadoTrasacciones";
            this.txtEstadoTrasacciones.Size = new System.Drawing.Size(183, 20);
            this.txtEstadoTrasacciones.TabIndex = 39;
            // 
            // LabelEstadoTrasacciones
            // 
            this.LabelEstadoTrasacciones.AutoSize = true;
            this.LabelEstadoTrasacciones.Location = new System.Drawing.Point(20, 152);
            this.LabelEstadoTrasacciones.Name = "LabelEstadoTrasacciones";
            this.LabelEstadoTrasacciones.Size = new System.Drawing.Size(40, 13);
            this.LabelEstadoTrasacciones.TabIndex = 38;
            this.LabelEstadoTrasacciones.Text = "Estado";
            // 
            // LabelDescripcionTrasacciones
            // 
            this.LabelDescripcionTrasacciones.AutoSize = true;
            this.LabelDescripcionTrasacciones.Location = new System.Drawing.Point(20, 97);
            this.LabelDescripcionTrasacciones.Name = "LabelDescripcionTrasacciones";
            this.LabelDescripcionTrasacciones.Size = new System.Drawing.Size(63, 13);
            this.LabelDescripcionTrasacciones.TabIndex = 37;
            this.LabelDescripcionTrasacciones.Text = "Descripcion";
            // 
            // LabelidTrasacciones
            // 
            this.LabelidTrasacciones.AutoSize = true;
            this.LabelidTrasacciones.Location = new System.Drawing.Point(20, 42);
            this.LabelidTrasacciones.Name = "LabelidTrasacciones";
            this.LabelidTrasacciones.Size = new System.Drawing.Size(18, 13);
            this.LabelidTrasacciones.TabIndex = 36;
            this.LabelidTrasacciones.Text = "ID";
            // 
            // txtIDTrasacciones
            // 
            this.txtIDTrasacciones.Location = new System.Drawing.Point(143, 42);
            this.txtIDTrasacciones.Name = "txtIDTrasacciones";
            this.txtIDTrasacciones.Size = new System.Drawing.Size(183, 20);
            this.txtIDTrasacciones.TabIndex = 35;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(877, 209);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(147, 34);
            this.button4.TabIndex = 45;
            this.button4.Text = "button4";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // btnEliminarTrasacciones
            // 
            this.btnEliminarTrasacciones.Location = new System.Drawing.Point(877, 115);
            this.btnEliminarTrasacciones.Name = "btnEliminarTrasacciones";
            this.btnEliminarTrasacciones.Size = new System.Drawing.Size(147, 34);
            this.btnEliminarTrasacciones.TabIndex = 44;
            this.btnEliminarTrasacciones.Text = "Eliminar";
            this.btnEliminarTrasacciones.UseVisualStyleBackColor = true;
            // 
            // btnEditarTrasacciones
            // 
            this.btnEditarTrasacciones.Location = new System.Drawing.Point(465, 209);
            this.btnEditarTrasacciones.Name = "btnEditarTrasacciones";
            this.btnEditarTrasacciones.Size = new System.Drawing.Size(147, 34);
            this.btnEditarTrasacciones.TabIndex = 43;
            this.btnEditarTrasacciones.Text = "Editar";
            this.btnEditarTrasacciones.UseVisualStyleBackColor = true;
            // 
            // btnAgregarTrasacciones
            // 
            this.btnAgregarTrasacciones.Location = new System.Drawing.Point(465, 115);
            this.btnAgregarTrasacciones.Name = "btnAgregarTrasacciones";
            this.btnAgregarTrasacciones.Size = new System.Drawing.Size(147, 34);
            this.btnAgregarTrasacciones.TabIndex = 42;
            this.btnAgregarTrasacciones.Text = "Agregar";
            this.btnAgregarTrasacciones.UseVisualStyleBackColor = true;
            this.btnAgregarTrasacciones.Click += new System.EventHandler(this.btnAgregarTrasacciones_Click);
            // 
            // labelTrasacciones
            // 
            this.labelTrasacciones.AutoSize = true;
            this.labelTrasacciones.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.labelTrasacciones.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTrasacciones.Location = new System.Drawing.Point(613, 16);
            this.labelTrasacciones.Name = "labelTrasacciones";
            this.labelTrasacciones.Size = new System.Drawing.Size(289, 39);
            this.labelTrasacciones.TabIndex = 41;
            this.labelTrasacciones.Text = "TRASACCIONES";
            // 
            // dtGRIDviewTrasacciones
            // 
            this.dtGRIDviewTrasacciones.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtGRIDviewTrasacciones.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtGRIDviewTrasacciones.Location = new System.Drawing.Point(12, 311);
            this.dtGRIDviewTrasacciones.Name = "dtGRIDviewTrasacciones";
            this.dtGRIDviewTrasacciones.Size = new System.Drawing.Size(1053, 292);
            this.dtGRIDviewTrasacciones.TabIndex = 46;
            // 
            // txtCuentaContableTrasacciones
            // 
            this.txtCuentaContableTrasacciones.Location = new System.Drawing.Point(143, 209);
            this.txtCuentaContableTrasacciones.Name = "txtCuentaContableTrasacciones";
            this.txtCuentaContableTrasacciones.Size = new System.Drawing.Size(183, 20);
            this.txtCuentaContableTrasacciones.TabIndex = 48;
            // 
            // labelCuentaContableTrasacciones
            // 
            this.labelCuentaContableTrasacciones.AutoSize = true;
            this.labelCuentaContableTrasacciones.Location = new System.Drawing.Point(20, 212);
            this.labelCuentaContableTrasacciones.Name = "labelCuentaContableTrasacciones";
            this.labelCuentaContableTrasacciones.Size = new System.Drawing.Size(86, 13);
            this.labelCuentaContableTrasacciones.TabIndex = 47;
            this.labelCuentaContableTrasacciones.Text = "Cuenta Contable";
            // 
            // Trasacciones
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1080, 615);
            this.Controls.Add(this.txtCuentaContableTrasacciones);
            this.Controls.Add(this.labelCuentaContableTrasacciones);
            this.Controls.Add(this.dtGRIDviewTrasacciones);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.btnEliminarTrasacciones);
            this.Controls.Add(this.btnEditarTrasacciones);
            this.Controls.Add(this.btnAgregarTrasacciones);
            this.Controls.Add(this.labelTrasacciones);
            this.Controls.Add(this.txtDescripcionTrasacciones);
            this.Controls.Add(this.txtEstadoTrasacciones);
            this.Controls.Add(this.LabelEstadoTrasacciones);
            this.Controls.Add(this.LabelDescripcionTrasacciones);
            this.Controls.Add(this.LabelidTrasacciones);
            this.Controls.Add(this.txtIDTrasacciones);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Trasacciones";
            this.Text = "Trasacciones";
            ((System.ComponentModel.ISupportInitialize)(this.dtGRIDviewTrasacciones)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtDescripcionTrasacciones;
        private System.Windows.Forms.TextBox txtEstadoTrasacciones;
        private System.Windows.Forms.Label LabelEstadoTrasacciones;
        private System.Windows.Forms.Label LabelDescripcionTrasacciones;
        private System.Windows.Forms.Label LabelidTrasacciones;
        private System.Windows.Forms.TextBox txtIDTrasacciones;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button btnEliminarTrasacciones;
        private System.Windows.Forms.Button btnEditarTrasacciones;
        private System.Windows.Forms.Button btnAgregarTrasacciones;
        private System.Windows.Forms.Label labelTrasacciones;
        private System.Windows.Forms.DataGridView dtGRIDviewTrasacciones;
        private System.Windows.Forms.TextBox txtCuentaContableTrasacciones;
        private System.Windows.Forms.Label labelCuentaContableTrasacciones;
    }
}
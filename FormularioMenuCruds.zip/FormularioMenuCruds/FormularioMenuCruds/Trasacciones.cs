﻿using FormularioMenuCruds.Config;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormularioMenuCruds
{
    public partial class Trasacciones : Form
    {
        public Trasacciones()
        {
            InitializeComponent();
        }

        public DataTable Index3()
        {
            Conexion.Conectar();
            DataTable dataTable = new DataTable();
            string sql = "SELECT * FROM  Trasacciones";
            SqlCommand cmd = new SqlCommand(sql, Conexion.Conectar());
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);

            adapter.Fill(dataTable);

            return dataTable;

        }

        private void btnAgregarTrasacciones_Click(object sender, EventArgs e)
        {
            Conexion.Conectar();
            string SQL_Insert = "INSERT INTO Trasacciones ( Descripcion, CuentaContable,Estado) VALUES (@Descripcion,@CuentaContable,@Estado)";
            SqlCommand command3 = new SqlCommand(SQL_Insert, Conexion.Conectar());


            command3.Parameters.AddWithValue("@CuentaContable",txtCuentaContableTrasacciones.Text);
            command3.Parameters.AddWithValue("@Descripcion",txtDescripcionTrasacciones.Text);
            command3.Parameters.AddWithValue("@Estado", txtEstadoTrasacciones.Text);
 

            command3.ExecuteNonQuery();

            MessageBox.Show("Datos añadidos correctamente!");

            dtGRIDviewTrasacciones.DataSource = Index3();
        }
    }
}

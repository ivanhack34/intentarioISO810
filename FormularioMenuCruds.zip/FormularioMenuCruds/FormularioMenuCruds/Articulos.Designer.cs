﻿namespace FormularioMenuCruds
{
    partial class Articulos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtIDarticulos = new System.Windows.Forms.TextBox();
            this.txtDescripcionArticulos = new System.Windows.Forms.TextBox();
            this.txtIDTipoInventarioArticulos = new System.Windows.Forms.TextBox();
            this.txtExistenciaArticulos = new System.Windows.Forms.TextBox();
            this.LabelidArticulos = new System.Windows.Forms.Label();
            this.LabelDescripcionArticulos = new System.Windows.Forms.Label();
            this.LabelExistenciaArticulos = new System.Windows.Forms.Label();
            this.LabelIdTipoInventariosArticulos = new System.Windows.Forms.Label();
            this.LabelEstadoArticulos = new System.Windows.Forms.Label();
            this.txtEstadoArticulos = new System.Windows.Forms.TextBox();
            this.dtGRIDviewArticulos = new System.Windows.Forms.DataGridView();
            this.btnAgregarArticulos = new System.Windows.Forms.Button();
            this.btnEditarArticulos = new System.Windows.Forms.Button();
            this.btnEliminarArticulos = new System.Windows.Forms.Button();
            this.btnNuevoArticulos = new System.Windows.Forms.Button();
            this.txtCostoUnitarioArticulos = new System.Windows.Forms.TextBox();
            this.labelCostoUnitarioArticulos = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dtGRIDviewArticulos)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(594, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(214, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "ARTICULOS";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtIDarticulos
            // 
            this.txtIDarticulos.Location = new System.Drawing.Point(146, 37);
            this.txtIDarticulos.Name = "txtIDarticulos";
            this.txtIDarticulos.Size = new System.Drawing.Size(183, 20);
            this.txtIDarticulos.TabIndex = 1;
            // 
            // txtDescripcionArticulos
            // 
            this.txtDescripcionArticulos.Location = new System.Drawing.Point(146, 85);
            this.txtDescripcionArticulos.Name = "txtDescripcionArticulos";
            this.txtDescripcionArticulos.Size = new System.Drawing.Size(183, 20);
            this.txtDescripcionArticulos.TabIndex = 2;
            // 
            // txtIDTipoInventarioArticulos
            // 
            this.txtIDTipoInventarioArticulos.Location = new System.Drawing.Point(146, 194);
            this.txtIDTipoInventarioArticulos.Name = "txtIDTipoInventarioArticulos";
            this.txtIDTipoInventarioArticulos.Size = new System.Drawing.Size(183, 20);
            this.txtIDTipoInventarioArticulos.TabIndex = 3;
            // 
            // txtExistenciaArticulos
            // 
            this.txtExistenciaArticulos.Location = new System.Drawing.Point(146, 138);
            this.txtExistenciaArticulos.Name = "txtExistenciaArticulos";
            this.txtExistenciaArticulos.Size = new System.Drawing.Size(183, 20);
            this.txtExistenciaArticulos.TabIndex = 4;
            // 
            // LabelidArticulos
            // 
            this.LabelidArticulos.AutoSize = true;
            this.LabelidArticulos.Location = new System.Drawing.Point(23, 37);
            this.LabelidArticulos.Name = "LabelidArticulos";
            this.LabelidArticulos.Size = new System.Drawing.Size(18, 13);
            this.LabelidArticulos.TabIndex = 5;
            this.LabelidArticulos.Text = "ID";
            // 
            // LabelDescripcionArticulos
            // 
            this.LabelDescripcionArticulos.AutoSize = true;
            this.LabelDescripcionArticulos.Location = new System.Drawing.Point(23, 92);
            this.LabelDescripcionArticulos.Name = "LabelDescripcionArticulos";
            this.LabelDescripcionArticulos.Size = new System.Drawing.Size(63, 13);
            this.LabelDescripcionArticulos.TabIndex = 6;
            this.LabelDescripcionArticulos.Text = "Descripcion";
            this.LabelDescripcionArticulos.Click += new System.EventHandler(this.LabelDescripcionArticulos_Click);
            // 
            // LabelExistenciaArticulos
            // 
            this.LabelExistenciaArticulos.AutoSize = true;
            this.LabelExistenciaArticulos.Location = new System.Drawing.Point(23, 141);
            this.LabelExistenciaArticulos.Name = "LabelExistenciaArticulos";
            this.LabelExistenciaArticulos.Size = new System.Drawing.Size(55, 13);
            this.LabelExistenciaArticulos.TabIndex = 7;
            this.LabelExistenciaArticulos.Text = "Existencia";
            // 
            // LabelIdTipoInventariosArticulos
            // 
            this.LabelIdTipoInventariosArticulos.AutoSize = true;
            this.LabelIdTipoInventariosArticulos.Location = new System.Drawing.Point(23, 194);
            this.LabelIdTipoInventariosArticulos.Name = "LabelIdTipoInventariosArticulos";
            this.LabelIdTipoInventariosArticulos.Size = new System.Drawing.Size(107, 13);
            this.LabelIdTipoInventariosArticulos.TabIndex = 8;
            this.LabelIdTipoInventariosArticulos.Text = "ID Tipo de Inventario";
            // 
            // LabelEstadoArticulos
            // 
            this.LabelEstadoArticulos.AutoSize = true;
            this.LabelEstadoArticulos.Location = new System.Drawing.Point(23, 248);
            this.LabelEstadoArticulos.Name = "LabelEstadoArticulos";
            this.LabelEstadoArticulos.Size = new System.Drawing.Size(40, 13);
            this.LabelEstadoArticulos.TabIndex = 9;
            this.LabelEstadoArticulos.Text = "Estado";
            // 
            // txtEstadoArticulos
            // 
            this.txtEstadoArticulos.Location = new System.Drawing.Point(146, 241);
            this.txtEstadoArticulos.Name = "txtEstadoArticulos";
            this.txtEstadoArticulos.Size = new System.Drawing.Size(183, 20);
            this.txtEstadoArticulos.TabIndex = 10;
            // 
            // dtGRIDviewArticulos
            // 
            this.dtGRIDviewArticulos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtGRIDviewArticulos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtGRIDviewArticulos.Location = new System.Drawing.Point(12, 337);
            this.dtGRIDviewArticulos.Name = "dtGRIDviewArticulos";
            this.dtGRIDviewArticulos.Size = new System.Drawing.Size(1056, 266);
            this.dtGRIDviewArticulos.TabIndex = 11;
            this.dtGRIDviewArticulos.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtGRIDviewArticulos_CellContentDoubleClick);
            // 
            // btnAgregarArticulos
            // 
            this.btnAgregarArticulos.Location = new System.Drawing.Point(399, 129);
            this.btnAgregarArticulos.Name = "btnAgregarArticulos";
            this.btnAgregarArticulos.Size = new System.Drawing.Size(147, 34);
            this.btnAgregarArticulos.TabIndex = 12;
            this.btnAgregarArticulos.Text = "Agregar";
            this.btnAgregarArticulos.UseVisualStyleBackColor = true;
            this.btnAgregarArticulos.Click += new System.EventHandler(this.btnAgregarArticulos_Click);
            // 
            // btnEditarArticulos
            // 
            this.btnEditarArticulos.Location = new System.Drawing.Point(399, 271);
            this.btnEditarArticulos.Name = "btnEditarArticulos";
            this.btnEditarArticulos.Size = new System.Drawing.Size(147, 34);
            this.btnEditarArticulos.TabIndex = 13;
            this.btnEditarArticulos.Text = "Editar";
            this.btnEditarArticulos.UseVisualStyleBackColor = true;
            this.btnEditarArticulos.Click += new System.EventHandler(this.btnEditarArticulos_Click);
            // 
            // btnEliminarArticulos
            // 
            this.btnEliminarArticulos.Location = new System.Drawing.Point(896, 129);
            this.btnEliminarArticulos.Name = "btnEliminarArticulos";
            this.btnEliminarArticulos.Size = new System.Drawing.Size(147, 34);
            this.btnEliminarArticulos.TabIndex = 14;
            this.btnEliminarArticulos.Text = "Eliminar";
            this.btnEliminarArticulos.UseVisualStyleBackColor = true;
            this.btnEliminarArticulos.Click += new System.EventHandler(this.btnEliminarArticulos_Click);
            // 
            // btnNuevoArticulos
            // 
            this.btnNuevoArticulos.Location = new System.Drawing.Point(896, 271);
            this.btnNuevoArticulos.Name = "btnNuevoArticulos";
            this.btnNuevoArticulos.Size = new System.Drawing.Size(147, 34);
            this.btnNuevoArticulos.TabIndex = 15;
            this.btnNuevoArticulos.Text = "Nuevo";
            this.btnNuevoArticulos.UseVisualStyleBackColor = true;
            this.btnNuevoArticulos.Click += new System.EventHandler(this.btnNuevoArticulos_Click);
            // 
            // txtCostoUnitarioArticulos
            // 
            this.txtCostoUnitarioArticulos.Location = new System.Drawing.Point(146, 290);
            this.txtCostoUnitarioArticulos.Name = "txtCostoUnitarioArticulos";
            this.txtCostoUnitarioArticulos.Size = new System.Drawing.Size(183, 20);
            this.txtCostoUnitarioArticulos.TabIndex = 17;
            // 
            // labelCostoUnitarioArticulos
            // 
            this.labelCostoUnitarioArticulos.AutoSize = true;
            this.labelCostoUnitarioArticulos.Location = new System.Drawing.Point(23, 297);
            this.labelCostoUnitarioArticulos.Name = "labelCostoUnitarioArticulos";
            this.labelCostoUnitarioArticulos.Size = new System.Drawing.Size(73, 13);
            this.labelCostoUnitarioArticulos.TabIndex = 16;
            this.labelCostoUnitarioArticulos.Text = "Costo Unitario";
            // 
            // Articulos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1080, 615);
            this.Controls.Add(this.txtCostoUnitarioArticulos);
            this.Controls.Add(this.labelCostoUnitarioArticulos);
            this.Controls.Add(this.btnNuevoArticulos);
            this.Controls.Add(this.btnEliminarArticulos);
            this.Controls.Add(this.btnEditarArticulos);
            this.Controls.Add(this.btnAgregarArticulos);
            this.Controls.Add(this.dtGRIDviewArticulos);
            this.Controls.Add(this.txtEstadoArticulos);
            this.Controls.Add(this.LabelEstadoArticulos);
            this.Controls.Add(this.LabelIdTipoInventariosArticulos);
            this.Controls.Add(this.LabelExistenciaArticulos);
            this.Controls.Add(this.LabelDescripcionArticulos);
            this.Controls.Add(this.LabelidArticulos);
            this.Controls.Add(this.txtExistenciaArticulos);
            this.Controls.Add(this.txtIDTipoInventarioArticulos);
            this.Controls.Add(this.txtDescripcionArticulos);
            this.Controls.Add(this.txtIDarticulos);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Articulos";
            this.Text = "Articulos";
            this.Load += new System.EventHandler(this.Articulos_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtGRIDviewArticulos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtIDarticulos;
        private System.Windows.Forms.TextBox txtDescripcionArticulos;
        private System.Windows.Forms.TextBox txtIDTipoInventarioArticulos;
        private System.Windows.Forms.TextBox txtExistenciaArticulos;
        private System.Windows.Forms.Label LabelidArticulos;
        private System.Windows.Forms.Label LabelDescripcionArticulos;
        private System.Windows.Forms.Label LabelExistenciaArticulos;
        private System.Windows.Forms.Label LabelIdTipoInventariosArticulos;
        private System.Windows.Forms.Label LabelEstadoArticulos;
        private System.Windows.Forms.TextBox txtEstadoArticulos;
        private System.Windows.Forms.DataGridView dtGRIDviewArticulos;
        private System.Windows.Forms.Button btnAgregarArticulos;
        private System.Windows.Forms.Button btnEditarArticulos;
        private System.Windows.Forms.Button btnEliminarArticulos;
        private System.Windows.Forms.Button btnNuevoArticulos;
        private System.Windows.Forms.TextBox txtCostoUnitarioArticulos;
        private System.Windows.Forms.Label labelCostoUnitarioArticulos;
    }
}
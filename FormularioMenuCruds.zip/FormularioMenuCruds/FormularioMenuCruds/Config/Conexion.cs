﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormularioMenuCruds.Config
{
      class Conexion
    {
        public static SqlConnection Conectar ()
        {
            SqlConnection conexion = new SqlConnection("server =CESARS\\SQLEXPRESS; database =dbSegundoParcial; Trusted_Connection=True;");


            conexion.Open();
            return conexion;  
                
        }
}
}
